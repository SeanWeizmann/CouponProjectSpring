package coupon_project.login;

public enum ClientType {

    ADMINISTRATOR,
    COMPANY,
    CUSTOMER
}
