package coupon_project.entities;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

public enum Categories {
    FOOD,
    ELECTRICITY,
    RESTAURANT,
    VACATION;


}
